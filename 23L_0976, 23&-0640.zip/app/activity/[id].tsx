import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, SafeAreaView,
  StatusBar, TouchableOpacity, Dimensions, Alert, Modal, TextInput, ActivityIndicator, Platform
} from 'react-native';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { LineChart } from 'react-native-chart-kit';
import DateTimePicker from '@react-native-community/datetimepicker';
import {
  useFonts, Nunito_400Regular, Nunito_600SemiBold,
  Nunito_700Bold, Nunito_800ExtraBold,
} from '@expo-google-fonts/nunito';
import { useAuth } from '@/context/AuthContext';
import { addActivityLog, getActivitiesInRange, calculateCalories, ActivityLog } from '@/services/firestoreService';
import { useActivities } from '@/context/ActivityContext';

const W = Dimensions.get('window').width;

export default function ActivityScreen() {
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const { user, userProfile } = useAuth();
  const { workouts, refreshActivities } = useActivities();
  
  const [fontsLoaded] = useFonts({
    Nunito_400Regular, Nunito_600SemiBold, Nunito_700Bold, Nunito_800ExtraBold,
  });

  const workout = workouts.find(w => w.id === id);

  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const [showModal, setShowModal] = useState(false);
  const [duration, setDuration] = useState('');
  const [distance, setDistance] = useState('');
  const [date, setDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [pickerMode, setPickerMode] = useState<'date' | 'time'>('date');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (user && workout) {
      fetchData();
    } else if (!workout && workouts.length > 0) {
      // If workout not found after workouts loaded, go back
      Alert.alert('Error', 'Workout not found');
      router.back();
    }
  }, [user, workout, workouts]);

  const fetchData = async () => {
    if (!user || !workout) return;
    setIsLoading(true);
    try {
      const today = new Date();
      const weekAgo = new Date();
      weekAgo.setDate(today.getDate() - 6);
      const data = await getActivitiesInRange(user.uid, weekAgo.toISOString().split('T')[0], today.toISOString().split('T')[0]);
      setLogs(data.filter(a => a.type === workout.name));
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogActivity = async () => {
    if (!duration || !workout) {
      Alert.alert('Error', 'Please enter duration');
      return;
    }
    if (!user || !userProfile) return;

    setIsSubmitting(true);
    try {
      const durNum = parseInt(duration);
      const distNum = distance.trim() ? parseFloat(distance.replace(',', '.')) : 0;
      const calories = calculateCalories(workout.metScore, durNum, userProfile.weightKg);

      const logData: any = {
        type: workout.name,
        durationMin: durNum,
        caloriesBurned: calories,
        date: date.toISOString().split('T')[0],
        time: date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
      };

      if (!isNaN(distNum) && distNum > 0) {
        logData.distance = distNum;
      }

      await addActivityLog(user.uid, logData);

      Alert.alert('Success', 'Activity logged successfully!');
      setShowModal(false);
      setDuration('');
      setDistance('');
      fetchData();
      refreshActivities();
    } catch (err) {
      Alert.alert('Error', 'Failed to log activity');
    } finally {
      setIsSubmitting(false);
    }
  };

  const onDateChange = (event: any, selectedDate?: Date) => {
    if (event.type === 'dismissed') {
      setShowDatePicker(false);
      return;
    }
    const currentDate = selectedDate || date;
    if (Platform.OS === 'android') {
      if (pickerMode === 'date') {
        setDate(currentDate);
        setPickerMode('time');
      } else {
        setShowDatePicker(false);
        setDate(currentDate);
        setPickerMode('date');
      }
    } else {
      setDate(currentDate);
    }
  };

  if (!fontsLoaded || !workout) return null;

  const totalDistance = logs.reduce((sum, log) => sum + (log.distance || 0), 0);
  const totalTime = logs.reduce((sum, log) => sum + log.durationMin, 0);
  const totalCalories = logs.reduce((sum, log) => sum + log.caloriesBurned, 0);

  const chartData = [0, 0, 0, 0, 0, 0, 0];
  const labels = ['6d', '5d', '4d', '3d', '2d', '1d', 'Today'];
  if (logs.length > 0) {
    const today = new Date();
    today.setHours(0,0,0,0);
    logs.forEach(log => {
      try {
        const logDate = new Date(log.date + 'T00:00:00');
        const diffTime = Math.abs(today.getTime() - logDate.getTime());
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays >= 0 && diffDays < 7) {
          // If distance exists, plot it, otherwise plot duration
          chartData[6 - diffDays] += (log.distance || log.durationMin);
        }
      } catch (e) {}
    });
  }

  const hasDistance = logs.some(l => l.distance && l.distance > 0);
  const chartUnit = hasDistance ? 'km' : 'min';

  const weekData = {
    labels,
    datasets: [{ data: chartData.some(d => d > 0) ? chartData : [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1], strokeWidth: 2 }],
  };

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor="#13131f" />
      <View style={s.container}>
        <TouchableOpacity style={s.backBtn} onPress={() => router.back()}><FontAwesome name="chevron-left" size={16} color="#fff" /></TouchableOpacity>
        
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 24 }}>
          <View style={[s.iconBox, { backgroundColor: workout.color + '33' }]}>
            <FontAwesome name={workout.icon as any} size={28} color={workout.color} />
          </View>
          <Text style={s.title}>{workout.name}</Text>
        </View>

        {isLoading ? (
          <ActivityIndicator size="large" color={workout.color} style={{ marginTop: 50 }} />
        ) : (
          <>
            <View style={s.statsGrid}>
              {[
                { label: 'Total Logs', value: logs.length.toString(), unit: '' },
                { label: 'Calories (7d)', value: totalCalories.toString(), unit: 'kcal' },
                { label: 'Active Time', value: totalTime.toString(), unit: 'min' },
                ...(hasDistance ? [{ label: 'Distance', value: totalDistance.toFixed(1), unit: 'km' }] : []),
              ].map((stat) => (
                <View key={stat.label} style={s.statCard}>
                  <Text style={s.statLabel}>{stat.label}</Text>
                  <View style={{ flexDirection: 'row', alignItems: 'baseline' }}>
                    <Text style={s.statValue}>{stat.value}</Text>
                    {stat.unit ? <Text style={s.statUnit}>{stat.unit}</Text> : null}
                  </View>
                </View>
              ))}
            </View>
            <View style={s.chartCard}>
              <Text style={s.chartTitle}>Weekly {hasDistance ? 'Distance' : 'Duration'} ({chartUnit})</Text>
              <LineChart
                data={weekData} width={W - 64} height={180}
                chartConfig={{
                  backgroundColor: '#1e1e30', backgroundGradientFrom: '#1e1e30', backgroundGradientTo: '#1e1e30',
                  decimalPlaces: 1, color: (opacity = 1) => workout.color + Math.round(opacity * 255).toString(16).padStart(2, '0'),
                  labelColor: (opacity = 1) => `rgba(153,153,187,${opacity})`,
                  propsForDots: { r: '4', strokeWidth: '2', stroke: workout.color },
                  propsForBackgroundLines: { stroke: '#2e2e44', strokeDasharray: '4' },
                }}
                bezier style={{ borderRadius: 12, marginTop: 8 }} withShadow={false}
              />
            </View>
          </>
        )}
      </View>
      <View style={s.footer}>
        <TouchableOpacity style={[s.startBtn, { backgroundColor: workout.color }]} onPress={() => { setPickerMode('date'); setShowModal(true); }}>
          <FontAwesome name="plus" size={16} color="#fff" style={{ marginRight: 10 }} /><Text style={s.startBtnText}>Log Activity</Text>
        </TouchableOpacity>
      </View>
      <Modal visible={showModal} transparent animationType="slide">
        <View style={s.modalOverlay}>
          <View style={s.modalCard}>
            <Text style={s.modalTitle}>Log {workout.name} Session</Text>
            <View style={s.inputWrap}>
              <Text style={s.modalLabel}>Activity Date & Time</Text>
              <TouchableOpacity style={s.modalInput} onPress={() => { setPickerMode('date'); setShowDatePicker(true); }}>
                <Text style={{ color: '#fff' }}>{date.toLocaleString()}</Text>
              </TouchableOpacity>
              {showDatePicker && (
                <DateTimePicker
                  value={date} mode={Platform.OS === 'ios' ? 'datetime' : pickerMode}
                  display={Platform.OS === 'ios' ? 'spinner' : 'default'} onChange={onDateChange} maximumDate={new Date()}
                />
              )}
            </View>
            <View style={s.inputWrap}>
              <Text style={s.modalLabel}>Duration (minutes)</Text>
              <TextInput style={s.modalInput} value={duration} onChangeText={setDuration} keyboardType="numeric" placeholderTextColor="#666" />
            </View>
            <View style={s.inputWrap}>
              <Text style={s.modalLabel}>Distance (km) (Optional)</Text>
              <TextInput style={s.modalInput} value={distance} onChangeText={setDistance} keyboardType="numeric" placeholderTextColor="#666" />
            </View>
            <View style={s.modalActions}>
              <TouchableOpacity style={s.modalCancel} onPress={() => setShowModal(false)} disabled={isSubmitting}><Text style={s.modalCancelText}>Cancel</Text></TouchableOpacity>
              <TouchableOpacity style={[s.modalSave, { backgroundColor: workout.color }]} onPress={handleLogActivity} disabled={isSubmitting}><Text style={s.modalSaveText}>{isSubmitting ? 'Saving...' : 'Save'}</Text></TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#13131f' },
  container: { flex: 1, paddingHorizontal: 24, paddingTop: 20 },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#1e1e30', alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  title: { fontFamily: 'Nunito_800ExtraBold', fontSize: 36, color: '#fff', marginLeft: 16 },
  iconBox: { width: 56, height: 56, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 24 },
  statCard: { width: '47%', backgroundColor: '#1e1e30', borderRadius: 16, padding: 16, borderWidth: 1, borderColor: '#2e2e44' },
  statLabel: { fontFamily: 'Nunito_400Regular', fontSize: 12, color: '#9999bb', marginBottom: 6 },
  statValue: { fontFamily: 'Nunito_800ExtraBold', fontSize: 26, color: '#fff' },
  statUnit: { fontFamily: 'Nunito_400Regular', fontSize: 14, color: '#9999bb', marginLeft: 3 },
  chartCard: { backgroundColor: '#1e1e30', borderRadius: 20, padding: 16, borderWidth: 1, borderColor: '#2e2e44' },
  chartTitle: { fontFamily: 'Nunito_700Bold', fontSize: 17, color: '#fff' },
  footer: { paddingHorizontal: 24, paddingBottom: 32 },
  startBtn: { borderRadius: 18, height: 58, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  startBtnText: { fontFamily: 'Nunito_700Bold', fontSize: 18, color: '#fff' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', padding: 24 },
  modalCard: { backgroundColor: '#1e1e30', borderRadius: 20, padding: 24, borderWidth: 1, borderColor: '#2e2e44' },
  modalTitle: { fontFamily: 'Nunito_700Bold', fontSize: 20, color: '#fff', marginBottom: 20 },
  inputWrap: { marginBottom: 16 },
  modalLabel: { fontFamily: 'Nunito_600SemiBold', fontSize: 13, color: '#9999bb', marginBottom: 8 },
  modalInput: { backgroundColor: '#13131f', borderRadius: 12, padding: 14, fontFamily: 'Nunito_600SemiBold', fontSize: 16, color: '#e0e0ff', borderWidth: 1, borderColor: '#2e2e44', justifyContent: 'center' },
  modalActions: { flexDirection: 'row', justifyContent: 'flex-end', gap: 12, marginTop: 10 },
  modalCancel: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12, backgroundColor: '#13131f', borderWidth: 1, borderColor: '#2e2e44' },
  modalCancelText: { fontFamily: 'Nunito_600SemiBold', fontSize: 14, color: '#9999bb' },
  modalSave: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12 },
  modalSaveText: { fontFamily: 'Nunito_700Bold', fontSize: 14, color: '#fff' },
});
